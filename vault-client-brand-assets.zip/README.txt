Vault Client brand assets
-------------------------
VaultClient.ico: multi-resolution Windows application icon.
VaultClient.png: 256x256 client app icon PNG.
vault-client-primary-logo.png: high-resolution client identity artwork.
vault-client-icon-master.png: square client icon master crop.
favicon-*.png: resized PNG variants for web/app use.

These are raster assets cropped from the generated branding sheet, not editable vector artwork. Inspect small favicon sizes at actual display size before shipping.
